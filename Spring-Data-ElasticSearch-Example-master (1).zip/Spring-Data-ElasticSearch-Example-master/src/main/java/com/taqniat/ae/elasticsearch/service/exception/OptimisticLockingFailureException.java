package com.taqniat.ae.elasticsearch.service.exception;

public class OptimisticLockingFailureException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public OptimisticLockingFailureException(String msg) {
		super(msg);
	}
}
