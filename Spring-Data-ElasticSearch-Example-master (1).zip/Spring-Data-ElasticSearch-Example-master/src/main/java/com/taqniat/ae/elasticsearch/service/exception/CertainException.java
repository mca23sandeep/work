package com.taqniat.ae.elasticsearch.service.exception;

public class CertainException {

}
