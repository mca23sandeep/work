package com.taqniat.ae.elasticsearch.service;

import org.elasticsearch.search.SearchHits;

import com.taqniat.ae.elasticsearch.model.EmployeeSearchCriteria;

public interface EmployeeService {

	public SearchHits searchEmployeesByName(EmployeeSearchCriteria elasticSearchRequest) throws Exception;
		public SearchHits getEmployeesOnSpecificStates(EmployeeSearchCriteria employeeQueryCriteria) throws Exception;
	public SearchHits getEmployeesOnSpecificLeaveQuarter(EmployeeSearchCriteria elasticSearchRequest) throws Exception;
	public SearchHits getEmployeesTop10PercentSalary(EmployeeSearchCriteria elasticSearchRequest) throws Exception;
	
	public SearchHits getEmployeesOnSpecificLeaveDates(EmployeeSearchCriteria elasticSearchRequest) throws Exception;
}
