package com.taqniat.ae.elasticsearch.service;

import java.util.List;
import java.util.Map;

public interface BulkUploadService {

	public String bulkUpload(String indexName, List<Map<String, Object>> dataList) throws Exception;
}
