package com.taqniat.ae.elasticsearch.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.taqniat.ae.elasticsearch.model.EmployeeSearchCriteria;

import lombok.extern.slf4j.Slf4j;

@Service
@SuppressWarnings("deprecation")
@Slf4j
public class EmployeeServiceRestImpl {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ObjectMapper objectMapper;

	private static final String ELASTICSEARCH_URL = "http://localhost:9200/employees_aggregated_data2/_search";

	

	public String buildJsonQuery(EmployeeSearchCriteria elasticSearchRequest) {
		ObjectNode root = objectMapper.createObjectNode();
		ObjectNode queryNode = root.putObject("query");
		ObjectNode boolNode = queryNode.putObject("bool");
		ArrayNode shouldNode = boolNode.putArray("should");
		shouldNode.addObject().putObject("match_phrase").put("empname", elasticSearchRequest.getNamePhrase1());
		shouldNode.addObject().putObject("match_phrase").put("empname", elasticSearchRequest.getNamePhrase2());
		boolNode.put("minimum_should_match", 1);
		return root.toString();
	}

	public ResponseEntity<String> searchEmployeesByName(EmployeeSearchCriteria elasticSearchRequest) throws Exception {
		log.info(" :::::" + elasticSearchRequest);
		return httpCall(buildQuerySearchEmployeesByName(elasticSearchRequest));
	}



	public ResponseEntity<String> httpCall(String jsonQuery) {
		log.info(" :::::" + jsonQuery);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(jsonQuery, headers);
		ResponseEntity<String> response = restTemplate.exchange(ELASTICSEARCH_URL, HttpMethod.GET, entity,
				String.class);
		log.info(" :::::" + response);
		log.info(" :::::" + response);
		return response;
	}
	
	private String buildQuerySearchEmployeesByName(EmployeeSearchCriteria elasticSearchRequest) {
		String query = "{\n" + "  \"query\": {\n" + "    \"bool\": {\n" + "      \"should\": [\n"
				+ "        { \"match_phrase\": { \"empname\": \"" + elasticSearchRequest.getNamePhrase1() + "\" } },\n"
				+ "        { \"match_phrase\": { \"empname\": \"" + elasticSearchRequest.getNamePhrase2() + "\" } }\n"
				+ "      ],\n" + "      \"minimum_should_match\": 1\n" + "    }\n" + "  }\n" + "}";

		log.info(" :::::" + query);
		return query;
	}
	
	public ResponseEntity<String> getEmployeesOnSpecificStates(EmployeeSearchCriteria searchCriteria) {
		StringBuilder stateMatches = new StringBuilder();
		if (stateMatches.length() > 0) {
			stateMatches.setLength(stateMatches.length() - 1); // Remove the trailing comma
		}
		if (searchCriteria.getStates() != null) {
			for (String state : searchCriteria.getStates()) {
				stateMatches.append("{ \"match\": { \"addresses.state\": \"" + state + "\" } },");
			}
			if (stateMatches.length() > 0) {
				stateMatches.setLength(stateMatches.length() - 1); // Remove the trailing comma
			}
		}
		String jsonQuery = "{\n" + "  \"query\": {\n" + "    \"bool\": {\n" + "      \"must\": [\n" + "        {\n"
				+ "          \"range\": {\n" + "            \"joinDate\": {\n" + "              \"gte\": \""
				+ searchCriteria.getJoinDateStart() + "\",\n" + "              \"lte\": \""
				+ searchCriteria.getJoinDateEnd() + "\"\n" + "            }\n" + "          }\n" + "        },\n"
				+ "        {\n" + "          \"nested\": {\n" + "            \"path\": \"addresses\",\n"
				+ "            \"query\": {\n" + "              \"bool\": {\n" + "                \"should\": [\n"
				+ "                  " + stateMatches.toString() + "\n" + "                ],\n"
				+ "                \"minimum_should_match\": 1\n" + "              }\n" + "            }\n"
				+ "          }\n" + "        }\n" + "      ],\n" + "      \"filter\": [\n" + "        {\n"
				+ "          \"bool\": {\n" + "            \"should\": [\n" + "              {\n"
				+ "                \"nested\": {\n" + "                  \"path\": \"salary\",\n"
				+ "                  \"query\": {\n" + "                    \"range\": {\n"
				+ "                      \"salary.amount\": {\n" + "                        \"gte\": "
				+ searchCriteria.getSalaryMin() + ",\n" + "                        \"lte\": "
				+ searchCriteria.getSalaryMax() + "\n" + "                      }\n" + "                    }\n"
				+ "                  }\n" + "                }\n" + "              },\n" + "              {\n"
				+ "                \"nested\": {\n" + "                  \"path\": \"leave_summary\",\n"
				+ "                  \"query\": {\n" + "                    \"bool\": {\n"
				+ "                      \"must\": [\n"
				+ "                        { \"term\": { \"leave_summary.leave_type\": \""
				+ searchCriteria.getLeaveType() + "\" } },\n"
				+ "                        { \"term\": { \"leave_summary.year\": 2025 } },\n"
				+ "                        { \"range\": { \"leave_summary.sick_count\": { \"gt\": "
				+ searchCriteria.getMinimumSickLeaves() + " } } }\n" + "                      ]\n"
				+ "                    }\n" + "                  }\n" + "                }\n" + "              },\n"
				+ "              {\n" + "                \"range\": {\n"
				+ "                  \"leave_summary.leave_start_date\": {\n" + "                    \"gte\": \""
				+ searchCriteria.getLeaveStartDate() + "\"\n" + "                  }\n" + "                }\n"
				+ "              }\n" + "            ],\n" + "            \"minimum_should_match\": 1\n"
				+ "          }\n" + "        }\n" + "      ]\n" + "    }\n" + "  }\n" + "}";

		return httpCall(jsonQuery);
	}

}
