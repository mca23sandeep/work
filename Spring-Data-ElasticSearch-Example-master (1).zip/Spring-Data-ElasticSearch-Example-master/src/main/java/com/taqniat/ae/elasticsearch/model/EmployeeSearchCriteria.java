package com.taqniat.ae.elasticsearch.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmployeeSearchCriteria {
	@Builder.Default
	private Boolean defaultSearch = Boolean.TRUE;
	private String joinDateStart;
	private String joinDateEnd;
	private List<String> states;
	private Double salaryMin;
	private Double salaryMax;
	private String leaveType;
	private Integer minimumSickLeaves;
	private String leaveStartDate;

	private String leaveStartDateRangeStart;
	private String leaveStartDateRangeEnd;
	private List<String> excludedCountries;
	private List<String> includedCountries;
	private String sickLeaveType;
	private Integer minimumSickLeaveDays;
	private String sickLeaveStartDateRangeStart;
	private String sickLeaveStartDateRangeEnd;

	private String cityStartsWith;
	private String cityEndsWith; 
	private Boolean hasTakenLeave;
	
	
	private String leaveStartDateRangeJanuaryStart;
    private String leaveStartDateRangeJanuaryEnd;  
    private String leaveStartDateRangeAugustStart;  
    private String leaveStartDateRangeAugustEnd; 
    
    
    private String namePhrase1; 
    private String namePhrase2;

}
