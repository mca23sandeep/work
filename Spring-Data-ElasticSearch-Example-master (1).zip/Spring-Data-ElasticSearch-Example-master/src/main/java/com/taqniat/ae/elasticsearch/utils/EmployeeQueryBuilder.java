package com.taqniat.ae.elasticsearch.utils;

import org.apache.lucene.search.join.ScoreMode;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import com.taqniat.ae.elasticsearch.model.EmployeeSearchCriteria;

public class EmployeeQueryBuilder {
	
	public static SearchSourceBuilder buildQuery(EmployeeSearchCriteria criteria) {
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        queryBuilder.must(QueryBuilders.rangeQuery("joinDate")
                .gte(criteria.getJoinDateStart())
                .lte(criteria.getJoinDateEnd()));
        BoolQueryBuilder statesQuery = QueryBuilders.boolQuery();
        for (String state : criteria.getStates()) {
            statesQuery.should(QueryBuilders.matchQuery("address.state", state));
        }
        statesQuery.minimumShouldMatch(1);
        queryBuilder.must(QueryBuilders.nestedQuery("address", statesQuery, ScoreMode.None));
        BoolQueryBuilder salaryOrSickLeaveQuery = QueryBuilders.boolQuery();
        salaryOrSickLeaveQuery.should(QueryBuilders.rangeQuery("salary.amount")
                .gte(criteria.getSalaryMin())
                .lte(criteria.getSalaryMax()));
        BoolQueryBuilder sickLeaveQuery = QueryBuilders.boolQuery()
                .must(QueryBuilders.matchQuery("leaves.leave_type", criteria.getLeaveType()))
                .must(QueryBuilders.rangeQuery("leaves.number_of_days").gte(criteria.getMinimumSickLeaves()))
                .must(QueryBuilders.rangeQuery("leaves.leave_start_date").gte(criteria.getLeaveStartDate()));
        salaryOrSickLeaveQuery.should(QueryBuilders.nestedQuery("leaves", sickLeaveQuery, ScoreMode.None));
        queryBuilder.must(salaryOrSickLeaveQuery);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(queryBuilder);
        return searchSourceBuilder;
    }
}
