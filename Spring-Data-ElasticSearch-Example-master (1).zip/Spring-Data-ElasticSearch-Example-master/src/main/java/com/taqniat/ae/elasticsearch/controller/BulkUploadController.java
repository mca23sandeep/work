package com.taqniat.ae.elasticsearch.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.taqniat.ae.elasticsearch.model.EmployeeSearchCriteria;
import com.taqniat.ae.elasticsearch.service.BulkUploadService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Bulk Upload", description = "Bulk Upload management APIs")
@RestController
public class BulkUploadController {

	@Autowired
	private BulkUploadService bulkUploadService;

	
	@Operation(summary = "bulkUpload", description = "Get a  bulkUpload", tags = {
			"Employees", "get" })
	@ApiResponses({ @ApiResponse(responseCode = "200", content = {
			@Content(schema = @Schema(implementation = EmployeeSearchCriteria.class), mediaType = "application/json") }),
			@ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
			@ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
	@PostMapping("/bulk-upload")
	public String bulkUpload(@RequestParam("indexName") String indexName, @RequestBody List<Map<String, Object>> dataList)
			throws Exception {
		return bulkUploadService.bulkUpload(indexName, dataList);
	}
}
