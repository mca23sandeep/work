package com.taqniat.ae.elasticsearch.service;

import java.util.Arrays;

import org.apache.lucene.search.join.ScoreMode;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchPhraseQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.NestedQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.index.query.WildcardQueryBuilder;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.nested.Nested;
import org.elasticsearch.search.aggregations.bucket.nested.NestedAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.Percentile;
import org.elasticsearch.search.aggregations.metrics.Percentiles;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taqniat.ae.elasticsearch.model.EmployeeSearchCriteria;

import lombok.extern.slf4j.Slf4j;

@Service
@SuppressWarnings("deprecation")
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private RestHighLevelClient client;

	public SearchHits searchEmployeesByName(EmployeeSearchCriteria elasticSearchRequest) throws Exception {
		SearchRequest searchRequest = new SearchRequest("employees_aggregated_data2");
		if (elasticSearchRequest.getDefaultSearch())
			elasticSearchRequest = EmployeeSearchCriteria.builder().namePhrase1("rt bro").namePhrase2("thew a").build();
		BoolQueryBuilder boolQuery = new BoolQueryBuilder();
		MatchPhraseQueryBuilder matchPhrase1 = new MatchPhraseQueryBuilder("empname",
				elasticSearchRequest.getNamePhrase1());
		MatchPhraseQueryBuilder matchPhrase2 = new MatchPhraseQueryBuilder("empname",
				elasticSearchRequest.getNamePhrase2());
		boolQuery.should(matchPhrase1);
		boolQuery.should(matchPhrase2);
		boolQuery.minimumShouldMatch(1);
		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
		sourceBuilder.query(boolQuery);
		searchRequest.source(sourceBuilder);
		return client.search(searchRequest, RequestOptions.DEFAULT).getHits();
	}

	public SearchHits getEmployeesOnSpecificLeaveDates(EmployeeSearchCriteria elasticSearchRequest) throws Exception {
		if (elasticSearchRequest.getDefaultSearch())
			elasticSearchRequest = EmployeeSearchCriteria.builder().leaveStartDateRangeJanuaryStart("2025-01-01")
					.leaveStartDateRangeJanuaryEnd("2025-01-31").leaveStartDateRangeAugustStart("2025-08-01")
					.leaveStartDateRangeAugustEnd("2025-08-31").build();

		SearchRequest searchRequest = new SearchRequest("employees_aggregated_data2");
		BoolQueryBuilder boolQuery = new BoolQueryBuilder();
		TermsQueryBuilder termsQuery1 = QueryBuilders.termsQuery("leaves.leave_start_date",
				elasticSearchRequest.getLeaveStartDateRangeJanuaryStart(),
				elasticSearchRequest.getLeaveStartDateRangeJanuaryEnd());
		TermsQueryBuilder termsQuery2 = QueryBuilders.termsQuery("leaves.leave_start_date",
				elasticSearchRequest.getLeaveStartDateRangeAugustStart(),
				elasticSearchRequest.getLeaveStartDateRangeAugustEnd());
		boolQuery.must(termsQuery1);
		boolQuery.must(termsQuery2);
		NestedQueryBuilder nestedQuery = new NestedQueryBuilder("leaves", boolQuery, ScoreMode.None);
		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
		sourceBuilder.query(nestedQuery);
		searchRequest.source(sourceBuilder);
		return client.search(searchRequest, RequestOptions.DEFAULT).getHits();
	}

	@Override
	public SearchHits getEmployeesOnSpecificStates(EmployeeSearchCriteria employeeQueryCriteria) throws Exception {
		if (employeeQueryCriteria.getDefaultSearch())
			employeeQueryCriteria = EmployeeSearchCriteria.builder().joinDateStart("now-6M/M").joinDateEnd("now/M")
					.states(Arrays.asList("California", "Texas", "Florida")).salaryMin(70000d).salaryMax(100000d)
					.leaveType("sick").minimumSickLeaves(3).leaveStartDate("now-1y/y").build();
		SearchRequest searchRequest = new SearchRequest("employees_aggregated_data2");
		BoolQueryBuilder boolQuery = new BoolQueryBuilder();
		boolQuery.must(new RangeQueryBuilder("joinDate").gte(employeeQueryCriteria.getJoinDateStart())
				.lte(employeeQueryCriteria.getJoinDateEnd()));
		BoolQueryBuilder boolQueryBuilder = new BoolQueryBuilder();
		for (String location : employeeQueryCriteria.getStates()) {
			boolQueryBuilder.should(new MatchQueryBuilder("address.state", location));
		}
		NestedQueryBuilder addressNestedQuery = new NestedQueryBuilder("address", boolQueryBuilder, ScoreMode.None);
		boolQuery.must(addressNestedQuery);
		BoolQueryBuilder filterQuery = new BoolQueryBuilder();
		NestedQueryBuilder salaryNestedQuery = new NestedQueryBuilder("salary", new RangeQueryBuilder("salary.amount")
				.gte(employeeQueryCriteria.getSalaryMin()).lte(employeeQueryCriteria.getSalaryMax()), ScoreMode.None);
		filterQuery.should(salaryNestedQuery);
		BoolQueryBuilder leaveSummaryQueryBuilder = new BoolQueryBuilder();
		leaveSummaryQueryBuilder.must(new TermQueryBuilder("leave_summary.year", 2025));
		leaveSummaryQueryBuilder.must(new RangeQueryBuilder("leave_summary.sick_count")
		        .gt(employeeQueryCriteria.getMinimumSickLeaves()));
		NestedQueryBuilder leaveSummaryNestedQuery = new NestedQueryBuilder("leave_summary", leaveSummaryQueryBuilder, ScoreMode.None);
		filterQuery.should(leaveSummaryNestedQuery);
		filterQuery.minimumShouldMatch(1); 
		boolQuery.filter(filterQuery);
		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
		sourceBuilder.query(boolQuery);
		searchRequest.source(sourceBuilder);
		logSearchRequest(searchRequest);
		SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
		/*
		 * NestedQueryBuilder sickLeaveNestedQuery = new NestedQueryBuilder("leaves",
		 * new BoolQueryBuilder() .must(new MatchQueryBuilder("leaves.leave_type",
		 * employeeQueryCriteria.getLeaveType())) .must(new
		 * RangeQueryBuilder("leaves.number_of_days").gt(employeeQueryCriteria.
		 * getMinimumSickLeaves())) .must(new
		 * RangeQueryBuilder("leaves.leave_start_date").gte(employeeQueryCriteria.
		 * getLeaveStartDate())), ScoreMode.None);
		 * filterQuery.should(sickLeaveNestedQuery); boolQuery.filter(filterQuery);
		 */
		return searchResponse.getHits();

	}

	private void logSearchRequest(SearchRequest searchRequest) {
		SearchSourceBuilder sourceBuilder = searchRequest.source();
		if (sourceBuilder != null) {
			String jsonRequest = sourceBuilder.toString();
			log.info("SearchRequest JSON: " + jsonRequest);
		} else {
			log.info("SearchRequest source is null.");
		}
	}

	@Override
	public SearchHits getEmployeesOnSpecificLeaveQuarter(EmployeeSearchCriteria criteria) throws Exception {
		SearchRequest searchRequest = new SearchRequest("employees_aggregated_data2");
		if (criteria.getDefaultSearch())
			criteria = EmployeeSearchCriteria.builder().leaveType("vacation").leaveStartDateRangeStart("2024-10-01")
					.leaveStartDateRangeEnd("2024-12-31").excludedCountries(Arrays.asList("USA"))
					.includedCountries(Arrays.asList("Canada")).salaryMin(80000.0).sickLeaveType("sick")
					.minimumSickLeaveDays(7).sickLeaveStartDateRangeStart("2025-01-01")
					.sickLeaveStartDateRangeEnd("2025-12-31").build();

		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
		BoolQueryBuilder boolQuery = new BoolQueryBuilder();
		NestedQueryBuilder vacationLeaveNestedQuery = new NestedQueryBuilder("leaves",
				QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("leaves.leave_type", criteria.getLeaveType()))
						.must(QueryBuilders.rangeQuery("leaves.leave_start_date")
								.gte(criteria.getLeaveStartDateRangeStart()).lte(criteria.getLeaveStartDateRangeEnd())),
				ScoreMode.None);
		boolQuery.must(vacationLeaveNestedQuery);
		BoolQueryBuilder filterQuery = new BoolQueryBuilder();
		NestedQueryBuilder addressNestedQuery = new NestedQueryBuilder("address",
				QueryBuilders.boolQuery()
						.should(QueryBuilders.termsQuery("address.country", criteria.getExcludedCountries()))
						.should(QueryBuilders.termsQuery("address.country", criteria.getIncludedCountries()))
						.minimumShouldMatch(1),
				ScoreMode.None);
		filterQuery.must(addressNestedQuery);
		NestedQueryBuilder salaryNestedQuery = new NestedQueryBuilder("salary",
				QueryBuilders.rangeQuery("salary.amount").gte(criteria.getSalaryMin()), ScoreMode.None);
		filterQuery.should(salaryNestedQuery);
		
		
		NestedQueryBuilder sickLeaveSummaryNestedQuery = new NestedQueryBuilder(
		        "leave_summary",
		        QueryBuilders.boolQuery()
		                .must(QueryBuilders.termQuery("leave_summary.year", 2025))
		                .must(QueryBuilders.rangeQuery("leave_summary.sick_count").gt(criteria.getMinimumSickLeaveDays())),
		        ScoreMode.None);
		filterQuery.should(sickLeaveSummaryNestedQuery);
		filterQuery.minimumShouldMatch(1);

		
		/*
		 * NestedQueryBuilder sickLeaveNestedQuery = new NestedQueryBuilder("leaves",
		 * QueryBuilders.boolQuery() .must(QueryBuilders.matchQuery("leaves.leave_type",
		 * criteria.getSickLeaveType()))
		 * .must(QueryBuilders.rangeQuery("leaves.number_of_days").gt(criteria.
		 * getMinimumSickLeaveDays()))
		 * .must(QueryBuilders.rangeQuery("leaves.leave_start_date")
		 * .gte(criteria.getSickLeaveStartDateRangeStart()).lte(criteria.
		 * getSickLeaveStartDateRangeEnd())), ScoreMode.None);
		 * filterQuery.should(sickLeaveNestedQuery);
		 */
	
		boolQuery.filter(filterQuery);
		sourceBuilder.query(boolQuery);
		searchRequest.source(sourceBuilder);
		logSearchRequest(searchRequest);
		SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
		return searchResponse.getHits();
	}

	@Override
	public SearchHits getEmployeesTop10PercentSalary(EmployeeSearchCriteria elasticSearchRequest) throws Exception {
		if (elasticSearchRequest.getDefaultSearch())
			elasticSearchRequest = EmployeeSearchCriteria.builder().joinDateStart("2025-01-01")
					.joinDateEnd("2025-03-31").cityStartsWith("").cityEndsWith("").salaryMax(150000.0)
					.hasTakenLeave(false).build();
		double topSalary = getTop10PercentSalary();
		return getEmployeesBasedOnTopSalary(elasticSearchRequest, topSalary).getHits();
	}

	private double getTop10PercentSalary() throws Exception {
		SearchRequest searchRequest = new SearchRequest("employees_aggregated_data2");
		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
		
		NestedAggregationBuilder nestedSalaryAgg = AggregationBuilders.nested("nested_salary", "salary")
		        .subAggregation(
		                AggregationBuilders.percentiles("top_10_percent_salary")
		                        .field("salary.amount")
		                        .percentiles(90d)
		        );
		sourceBuilder.size(0); 
		sourceBuilder.aggregation(nestedSalaryAgg);
		/*
		 * sourceBuilder.aggregation(
		 * AggregationBuilders.percentiles("top_10_percent_salary").field(
		 * "salary.amount").percentiles(90d)); searchRequest.source(sourceBuilder);
		 */
		SearchResponse response = client.search(searchRequest, RequestOptions.DEFAULT);
		/*
		 * Aggregations aggregations = response.getAggregations(); Percentiles
		 * top10PercentSalary = aggregations.get("top_10_percent_salary");
		 */
		Percentiles top10PercentSalary=null;
		Aggregations aggregations = response.getAggregations();
		if (aggregations != null) {
		    Nested nestedSalary = aggregations.get("nested_salary");
		    if (nestedSalary != null) {
		         top10PercentSalary = nestedSalary.getAggregations().get("top_10_percent_salary");
		        if (top10PercentSalary != null) {
		            for (Percentile percentile : top10PercentSalary) {
		                System.out.println("Percentile " + percentile.getPercent() + ": " + percentile.getValue());
		            }
		        }
		    }
		}
		
		return top10PercentSalary.percentile(90d);
	}

	private SearchResponse getEmployeesBasedOnTopSalary(EmployeeSearchCriteria elasticSearchRequest, double topSalary)
			throws Exception {
		SearchRequest searchRequest = new SearchRequest("employees_aggregated_data2");
		BoolQueryBuilder boolQuery = new BoolQueryBuilder();
		boolQuery.must(new RangeQueryBuilder("joinDate").gte(elasticSearchRequest.getJoinDateStart())
				.lte(elasticSearchRequest.getJoinDateEnd()));
		NestedQueryBuilder addressQuery = new NestedQueryBuilder("address",
				new BoolQueryBuilder()
						.should(new WildcardQueryBuilder("address.city", elasticSearchRequest.getCityStartsWith()))
						.should(new WildcardQueryBuilder("address.city", elasticSearchRequest.getCityEndsWith()))
						.minimumShouldMatch(1),
				ScoreMode.None);
		boolQuery.must(addressQuery);
		boolQuery.should(new BoolQueryBuilder().filter(new RangeQueryBuilder("salary.amount").gte(topSalary)));
		boolQuery.should(new BoolQueryBuilder().mustNot(new RangeQueryBuilder("leaves")));
		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
		sourceBuilder.query(boolQuery);
		searchRequest.source(sourceBuilder);
		return client.search(searchRequest, RequestOptions.DEFAULT);
	}

}
