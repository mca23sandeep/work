package com.taqniat.ae.elasticsearch.controller;

import org.elasticsearch.search.SearchHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.taqniat.ae.elasticsearch.model.EmployeeSearchCriteria;
import com.taqniat.ae.elasticsearch.service.EmployeeService;
import com.taqniat.ae.elasticsearch.service.EmployeeServiceRestImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
@Tag(name = "Employee", description = "Employee Management APIs")
@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	EmployeeServiceRestImpl employeeServiceRestImpl;

	@Operation(summary = "Retrieve EmployeesOnSpecificStates", description = "Get a EmployeesOnSpecificStates object by specifying its .", tags = {
			"Employees", "get" })
	@ApiResponses({
			@ApiResponse(responseCode = "200", content = {
					@Content(schema = @Schema(implementation = SearchHits.class), mediaType = "application/json") }),
			@ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
			@ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
	@GetMapping("/getEmployeesOnSpecificStates")
	public SearchHits getEmployeesOnSpecificStates(@RequestBody EmployeeSearchCriteria employeeQueryCriteria) throws Exception {
		
		return employeeService.getEmployeesOnSpecificStates(employeeQueryCriteria);
	}

	@Operation(summary = "Retrieve EmployeesOnSpecificLeave Quarter", description = "Get a  Employees OnSpecificLeave Quarter object by specifying its .", tags = {
			"Employees", "get" })
	@ApiResponses({
			@ApiResponse(responseCode = "200", content = {
					@Content(schema = @Schema(implementation = SearchHits.class), mediaType = "application/json") }),
			@ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
			@ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
	@GetMapping("/getEmployeesOnSpecificLeaveQuarter")
	public SearchHits getEmployeesOnSpecificLeaveQuarter(@RequestBody EmployeeSearchCriteria elasticSearchRequest) throws Exception {
		return employeeService.getEmployeesOnSpecificLeaveQuarter(elasticSearchRequest);
	}

	@Operation(summary = "Retrieve Top10PercentSalary", description = "Get a  Employees Specific Top10PercentSalary by specifying its .", tags = {
			"Employees", "get" })
	@ApiResponses({
			@ApiResponse(responseCode = "200", content = {
					@Content(schema = @Schema(implementation = SearchHits.class), mediaType = "application/json") }),
			@ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
			@ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
	@GetMapping("/getTop10PercentSalary")
	public SearchHits getTop10PercentSalary(@RequestBody  EmployeeSearchCriteria elasticSearchRequest) throws Exception {
		return employeeService.getEmployeesTop10PercentSalary(elasticSearchRequest);
	}

	@Operation(summary = "Retrieve Employees OnSpecific LeaveDates", description = "Get a  Employees OnSpecific LeaveDates object by specifying its .", tags = {
			"Employees", "get" })
	@ApiResponses({
			@ApiResponse(responseCode = "200", content = {
					@Content(schema = @Schema(implementation = SearchHits.class), mediaType = "application/json") }),
			@ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
			@ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
	@GetMapping("/getEmployeesOnSpecificLeaveDates")
	public SearchHits getEmployeesOnSpecificLeaveDates(@RequestBody  EmployeeSearchCriteria elasticSearchRequest) throws Exception {
		return employeeService.getEmployeesOnSpecificLeaveDates(elasticSearchRequest);
	}

	@Operation(summary = "Retrieve search EmployeesByName", description = "Get a  search Employees By Name object by specifying its .", tags = {
			"Employees", "get" })
	@ApiResponses({
			@ApiResponse(responseCode = "200", content = {
					@Content(schema = @Schema(implementation = SearchHits.class), mediaType = "application/json") }),
			@ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
			@ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
	@GetMapping("/searchEmployeesByName")
	public SearchHits searchEmployeesByName(@RequestBody EmployeeSearchCriteria employeeQueryCriteria)
			throws Exception {
		return employeeService.searchEmployeesByName(employeeQueryCriteria);
	}
	
	
	@Operation(summary = "Retrieve search EmployeesByName", description = "Get a  search Employees By Name object by specifying its .", tags = {
			"Employees", "get" })
	@ApiResponses({
			@ApiResponse(responseCode = "200", content = {
					@Content(schema = @Schema(implementation = SearchHits.class), mediaType = "application/json") }),
			@ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
			@ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
	@GetMapping("/rest/searchEmployeesByName")
	public ResponseEntity<String> searchEmployeesByNameRestTmp(@RequestBody EmployeeSearchCriteria employeeQueryCriteria)
			throws Exception {
		return employeeServiceRestImpl.searchEmployeesByName(employeeQueryCriteria);
	}
	

	@Operation(summary = "Retrieve EmployeesOnSpecificStates", description = "Get a EmployeesOnSpecificStates object by specifying its .", tags = {
			"Employees", "get" })
	@ApiResponses({
			@ApiResponse(responseCode = "200", content = {
					@Content(schema = @Schema(implementation = SearchHits.class), mediaType = "application/json") }),
			@ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
			@ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
	@GetMapping("/rest/getEmployeesOnSpecificStates")
	public  ResponseEntity<String> getEmployeesOnSpecificStatesRestTmp(@RequestBody EmployeeSearchCriteria employeeQueryCriteria) throws Exception {
		return employeeServiceRestImpl.getEmployeesOnSpecificStates(employeeQueryCriteria);
	}


}