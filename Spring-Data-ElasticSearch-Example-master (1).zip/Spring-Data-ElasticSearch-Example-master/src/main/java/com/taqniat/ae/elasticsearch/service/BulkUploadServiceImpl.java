package com.taqniat.ae.elasticsearch.service;

import java.util.List;
import java.util.Map;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@SuppressWarnings("deprecation")
@Service
public class BulkUploadServiceImpl implements BulkUploadService{

	@Autowired
	private RestHighLevelClient restHighLevelClient;

	public String bulkUpload(String indexName, List<Map<String, Object>> dataList) throws Exception {
		BulkRequest bulkRequest = new BulkRequest();
		for (Map<String, Object> data : dataList) {
			bulkRequest.add(new IndexRequest(indexName).source(data));
		}
		BulkResponse bulkResponse = restHighLevelClient.bulk(bulkRequest, RequestOptions.DEFAULT);
		if (bulkResponse.hasFailures()) {
			return "Bulk upload completed with errors: " + bulkResponse.buildFailureMessage();
		}
		return bulkResponse.status().toString();
	}
}